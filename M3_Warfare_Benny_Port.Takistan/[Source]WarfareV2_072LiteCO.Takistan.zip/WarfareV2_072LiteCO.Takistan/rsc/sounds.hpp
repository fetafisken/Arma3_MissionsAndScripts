class CfgSounds {
	sounds[] = {};
	
	//--- Mando Missiles - Sounds
	#include "Mando\mando_sounds.h"
};