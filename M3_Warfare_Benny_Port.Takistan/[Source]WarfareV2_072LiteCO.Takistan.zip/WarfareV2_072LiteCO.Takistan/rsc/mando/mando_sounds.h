	class mando_missile1
	{
		name = "mando_missile1";
		sound[] = {"\mando_missiles\sounds\mando_missile1.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_flares
	{
		name = "mando_flares";
		sound[] = {"\mando_missiles\sounds\mando_flares.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_radar1
	{
		name = "mando_radar1";
		sound[] = {"\mando_missiles\sounds\mando_radar1.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_radar2
	{
		name = "mando_radar2";
		sound[] = {"\mando_missiles\sounds\mando_radar2.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_target1
	{
		name = "mando_target1";
		sound[] = {"\mando_missiles\sounds\mando_target1.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_noammo1
	{
		name = "mando_noammo1";
		sound[] = {"\mando_missiles\sounds\mando_noammo1.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_noammo2
	{
		name = "mando_noammo2";
		sound[] = {"\mando_missiles\sounds\mando_noammo2.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_radaron
	{
		name = "mando_radaron";
		sound[] = {"\mando_missiles\sounds\mando_radaron.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_radaroff
	{
		name = "mando_radaroff";
		sound[] = {"\mando_missiles\sounds\mando_radaroff.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_lockedon
	{
		name = "mando_lockedon";
		sound[] = {"\mando_missiles\sounds\threatnewus.ogg", db-0, 1.0};
		titles[] = {0};
	};
	class mando_scud
	{
		name = "mando_scud";
		sound[] = {"\mando_missiles\sounds\mando_scud.ogg", db+50, 1.0};
		titles[] = {0};
	};
	class mando_gun_lite
	{
		name = "mando_gun_lite";
		sound[] = {"\mando_missiles\sounds\mando_gun_lite.ogg", db+20, 1.0};
		titles[] = {0};
	};
	class mando_gun
	{
		name = "mando_gun";
		sound[] = {"\mando_missiles\sounds\mando_gun.ogg", db+20, 1.0};
		titles[] = {0};
	};
	class mando_gun2
	{
		name = "mando_gun2";
		sound[] = {"\mando_missiles\sounds\mando_gun2.ogg", db+20, 1.0};
		titles[] = {0};
	};

	class mando_irtone
	{
		name = "mando_irtone";
		sound[] = {"\mando_missiles\sounds\mando_irtone.ogg", db+0, 1.0};
		titles[] = {0};
	};
	class mando_irgrowl
	{
		name = "mando_irgrowl";
		sound[] = {"\mando_missiles\sounds\mando_irgrowl.ogg", db+0, 1.0};
		titles[] = {0};
	};
	class mando_denied
	{
		name = "mando_denied";
		sound[] = {"\mando_missiles\sounds\mando_denied.ogg", db+0, 1.0};
		titles[] = {0};
	};
	class mando_ecm_on
	{
		name = "mando_ecm_on";
		sound[] = {"\mando_missiles\sounds\mando_ecm_on.ogg", db+0, 1.0};
		titles[] = {0};
	};
	class mando_ecm_off
	{
		name = "mando_ecm_off";
		sound[] = {"\mando_missiles\sounds\mando_ecm_off.ogg", db+0, 1.0};
		titles[] = {0};
	};
	class mando_LockBeep {
		name = "mando_LockBeep";
		sound[] = {"\mando_missiles\sounds\mando_lockbeep.ogg", 1.0, 1.0};
		titles[] ={0} ;	
	};
	class mando_LockTone {
		name = "mando_LockTone";
		sound[] = {"\mando_missiles\sounds\mando_locktone.ogg", 1.0, 1.0};
		titles[] ={0} ;	
	};

	class mando_visor {
		name = "mando_visor";
		sound[] = {"\mando_missiles\sounds\mando_visor.ogg", db+0, 1.0};
		titles[] ={} ;	
	};
	class mando_rearm {
		name = "mando_rearm";
		sound[] = {"\mando_missiles\sounds\mando_rearm.ogg", db+0, 1.0};
		titles[] ={} ;	
	};
	class mando_console_on {
		name = "mando_console_on";
		sound[] = {"\mando_missiles\sounds\mando_console_on.ogg", db+0, 1.0};
		titles[] ={} ;	
	};


